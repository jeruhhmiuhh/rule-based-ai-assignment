"""
Esoteric Journal & Dream Interpretation System
Rule-Based AI Assignment
-----------------------------------------------
A rule-based system that interprets journal entries and dream descriptions
using symbolic, astrological, tarot, and esoteric heuristics.
"""

# ── Symbol Libraries ─────────────────────────────────────────────────────────

# IF the user's input contains these keywords → THEN associate these symbols
WATER_SYMBOLS = ["water", "ocean", "river", "rain", "lake", "flood", "wave", "swim", "drown", "sea"]
FIRE_SYMBOLS  = ["fire", "flame", "burn", "candle", "sun", "light", "spark", "heat", "torch", "blaze"]
EARTH_SYMBOLS = ["earth", "ground", "mountain", "cave", "stone", "tree", "root", "soil", "forest", "buried"]
AIR_SYMBOLS   = ["wind", "sky", "cloud", "fly", "bird", "breath", "air", "feather", "storm", "fog"]
SHADOW_SYMBOLS = ["dark", "shadow", "black", "night", "fear", "chase", "lost", "trap", "hide", "nightmare"]
LIGHT_SYMBOLS  = ["light", "glow", "white", "gold", "angel", "star", "moon", "peace", "clear", "bright"]
DEATH_SYMBOLS  = ["death", "dead", "dying", "grave", "coffin", "skeleton", "ghost", "end", "funeral", "tomb"]
REBIRTH_SYMBOLS = ["birth", "baby", "new", "spring", "seed", "bloom", "transform", "butterfly", "egg", "awaken"]
LOVE_SYMBOLS   = ["love", "heart", "rose", "kiss", "embrace", "together", "longing", "desire", "connect", "union"]
JOURNEY_SYMBOLS = ["road", "path", "travel", "door", "bridge", "map", "lost", "direction", "destination", "walk"]

# Tarot card associations per theme
TAROT_MAP = {
    "water":   ("The Moon", "emotional depth, intuition, the subconscious, hidden truths"),
    "fire":    ("The Sun / The Emperor", "vitality, willpower, action, clarity, confidence"),
    "earth":   ("The Empress / The World", "abundance, grounding, fertility, material reality"),
    "air":     ("The Fool / The Star", "new beginnings, freedom, inspiration, higher perspective"),
    "shadow":  ("The Tower / The Devil", "disruption, shadow self, fear, restriction, transformation through chaos"),
    "light":   ("The High Priestess / The Star", "inner wisdom, hope, divine feminine, spiritual revelation"),
    "death":   ("Death / The Hermit", "endings that precede renewal, solitude, inner searching"),
    "rebirth": ("Judgement / The World", "awakening, completion, a new cycle beginning"),
    "love":    ("The Lovers / Two of Cups", "union, choice, partnership, soul connection"),
    "journey": ("The Chariot / The Fool", "willpower in motion, life's path, new adventures"),
}

# Astrological associations per theme
ASTRO_MAP = {
    "water":   "Neptune / Pisces / Cancer — ruled by emotion, dreams, and psychic sensitivity",
    "fire":    "Mars / Aries / Leo — ruled by will, courage, and creative force",
    "earth":   "Venus / Taurus / Virgo / Capricorn — ruled by stability, sensuality, and form",
    "air":     "Mercury / Gemini / Aquarius / Libra — ruled by intellect, communication, and freedom",
    "shadow":  "Pluto / Scorpio — ruled by transformation, power, and the unconscious",
    "light":   "Sun / Leo / Apollo — ruled by consciousness, identity, and divine illumination",
    "death":   "Saturn / Capricorn / Scorpio — ruled by endings, karma, and time",
    "rebirth": "Uranus / Pisces / Aries — ruled by sudden change, awakening, and new cycles",
    "love":    "Venus / Libra / 7th House — ruled by beauty, attraction, and relationship",
    "journey": "Jupiter / Sagittarius / 9th House — ruled by expansion, wisdom-seeking, and adventure",
}

# General esoteric guidance per theme
GUIDANCE_MAP = {
    "water":   "Your subconscious is speaking. This is a time for emotional honesty and introspection. Journaling, water rituals, or meditation near water may bring clarity.",
    "fire":    "A spark of transformation is alive in you. Harness this energy — it asks for bold action, creative expression, and release of what no longer serves.",
    "earth":   "You are being called back to your body and your foundations. Ground yourself through nature, physical ritual, or ancestral work.",
    "air":     "Your mind is active and seeking freedom. Ideas are forming. Pay attention to synchronicities and messages arriving unexpectedly.",
    "shadow":  "Something from the shadow self is asking to be seen. This is not a curse — it is an invitation for deep inner work and integration.",
    "light":   "You are moving toward illumination. A period of clarity, hope, and spiritual connection is opening. Trust the light you feel within.",
    "death":   "An ending is near or has already occurred. Honor it. Death in the esoteric sense is always a doorway — something new is on the other side.",
    "rebirth": "Transformation is underway. You are in a chrysalis state. Rest, reflect, and trust the process — emergence is coming.",
    "love":    "The heart is at the center of this dream or experience. Explore what you truly long for in connection, with others or with yourself.",
    "journey": "Your soul is on the move. This is a time of transition, learning, and stepping into the unknown with courage.",
}

# Journaling prompts per theme
PROMPT_MAP = {
    "water":   "Write about an emotion you have been avoiding. What does it feel like in your body? What does it need from you?",
    "fire":    "What are you most passionate about right now? Where in your life does that fire want to go?",
    "earth":   "Describe a place in nature where you feel safe. What does that place teach you about yourself?",
    "air":     "What new idea or possibility has been circling your mind? What would it mean to let yourself follow it?",
    "shadow":  "What part of yourself do you keep hidden from others — or from yourself? Give it a name and let it speak.",
    "light":   "Describe a moment when you felt truly at peace. What was present in that moment? How can you invite more of it?",
    "death":   "What chapter of your life is ending? Write a letter of farewell to it — honor what it gave you.",
    "rebirth": "Who are you becoming? Describe the version of yourself that is just beginning to emerge.",
    "love":    "What does your heart most deeply want right now? In relationship, in creativity, in life?",
    "journey": "If your life were a story, what chapter are you in right now? Where does the path seem to be leading?",
}


# ── Theme Detection ───────────────────────────────────────────────────────────

def detect_themes(text):
    """
    Scans the user's input for keywords matching each symbolic theme.
    Returns a list of matched theme names (could be multiple).
    Rule: IF keyword in input → THEN add theme to results.
    """
    text_lower = text.lower()
    detected = []

    # Check each symbol list against the user's text
    theme_checks = [
        ("water",   WATER_SYMBOLS),
        ("fire",    FIRE_SYMBOLS),
        ("earth",   EARTH_SYMBOLS),
        ("air",     AIR_SYMBOLS),
        ("shadow",  SHADOW_SYMBOLS),
        ("light",   LIGHT_SYMBOLS),
        ("death",   DEATH_SYMBOLS),
        ("rebirth", REBIRTH_SYMBOLS),
        ("love",    LOVE_SYMBOLS),
        ("journey", JOURNEY_SYMBOLS),
    ]

    for theme, keywords in theme_checks:
        for word in keywords:
            if word in text_lower:
                if theme not in detected:
                    detected.append(theme)
                break  # Only need one match per theme

    return detected


# ── Output Builder ────────────────────────────────────────────────────────────

def build_reading(themes, entry_type):
    """
    Given detected themes, assembles a full esoteric reading.
    Rule: IF theme detected → THEN output corresponding tarot, astrology, guidance, and prompt.
    """
    lines = []
    lines.append("\n" + "═" * 60)
    lines.append(f"  ✦ ESOTERIC {entry_type.upper()} READING ✦")
    lines.append("═" * 60)

    if not themes:
        # Fallback rule: IF no themes matched → THEN return a neutral reading
        lines.append("\nNo specific symbols were detected in your entry.")
        lines.append("This is the silence before the symbol speaks.")
        lines.append("\n🜃 Tarot Card: The Hanged Man")
        lines.append("   Meaning: Pause, surrender, seeing from a new angle.")
        lines.append("\n☿ Astrology: Neptune — the veiled, the dissolved, the in-between.")
        lines.append("\n📖 Journaling Prompt:")
        lines.append("   What are you waiting for? What would it mean to simply be still?")
        lines.append("\n" + "─" * 60)
        return "\n".join(lines)

    lines.append(f"\nSymbolic themes detected: {', '.join(t.upper() for t in themes)}\n")

    for theme in themes:
        tarot_name, tarot_meaning = TAROT_MAP[theme]
        astro = ASTRO_MAP[theme]
        guidance = GUIDANCE_MAP[theme]
        prompt = PROMPT_MAP[theme]

        lines.append(f"┌─ {theme.upper()} ─────────────────────────────────────")
        lines.append(f"│ 🜃 Tarot: {tarot_name}")
        lines.append(f"│   {tarot_meaning}")
        lines.append(f"│ ☿ Astrology: {astro}")
        lines.append(f"│ ✦ Guidance: {guidance}")
        lines.append(f"│ 📖 Journal Prompt: {prompt}")
        lines.append("└" + "─" * 53)
        lines.append("")

    return "\n".join(lines)


# ── Main Loop ─────────────────────────────────────────────────────────────────

def main():
    print("\n" + "★" * 60)
    print("  ESOTERIC JOURNAL & DREAM INTERPRETATION SYSTEM")
    print("  Rule-Based AI | Symbology · Tarot · Astrology")
    print("★" * 60)
    print("\nWelcome. This system interprets your journal entries and")
    print("dreams through the lens of esoteric symbolism, tarot, and astrology.")
    print("\nType 'quit' at any time to exit.\n")

    while True:
        # Rule: first ask what kind of entry this is
        print("─" * 60)
        entry_type = input("Are you sharing a [1] Dream or a [2] Journal Entry? (1/2): ").strip()

        # IF input is 1 → dream mode; IF 2 → journal mode; ELSE → default to journal
        if entry_type == "1":
            entry_label = "Dream"
            prompt_text = "\nDescribe your dream in as much detail as you like:\n> "
        elif entry_type == "2":
            entry_label = "Journal Entry"
            prompt_text = "\nShare your journal entry or what's on your mind:\n> "
        else:
            print("Defaulting to Journal Entry mode.")
            entry_label = "Journal Entry"
            prompt_text = "\nShare your journal entry or what's on your mind:\n> "

        user_input = input(prompt_text).strip()

        # IF user wants to quit → THEN exit the loop
        if user_input.lower() in ["quit", "exit", "q"]:
            print("\n✦ May your dreams be illuminating. Farewell. ✦\n")
            break

        # IF input is empty → THEN ask again
        if not user_input:
            print("Please share something so the symbols can speak.\n")
            continue

        # Detect symbolic themes in the user's input
        themes = detect_themes(user_input)

        # Build and print the esoteric reading
        reading = build_reading(themes, entry_label)
        print(reading)

        # Ask if the user wants to continue
        again = input("Would you like to share another entry? (yes/no): ").strip().lower()
        if again not in ["yes", "y"]:
            print("\n✦ May your dreams be illuminating. Farewell. ✦\n")
            break


if __name__ == "__main__":
    main()
